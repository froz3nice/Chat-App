package com.opop.brazius.chatroom;

public interface IUpdateRecyclerView {
    void updateRecyclerView(String body, boolean b, String myUsername, String notMyUsername);
}
